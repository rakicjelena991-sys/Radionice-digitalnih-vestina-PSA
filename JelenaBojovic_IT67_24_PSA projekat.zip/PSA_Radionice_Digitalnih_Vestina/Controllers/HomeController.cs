using System;
using System.Web.Mvc;
using PSARadionice.Models;

namespace PSARadionice.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Početna";
            return View();
        }

        public ActionResult Radionice()
        {
            ViewBag.Title = "Radionice";
            return View();
        }

        [HttpGet]
        public ActionResult Prijava()
        {
            ViewBag.Title = "Prijava";
            return View(new PrijavaRadionice());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Prijava(PrijavaRadionice model)
        {
            ViewBag.Title = "Prijava";
            string[] dozvoljeneRadionice = { "Osnove C#", "HTML i CSS", "Uvod u SQL" };
            string[] dozvoljeniNivoi = { "Početni", "Srednji" };

            if (Array.IndexOf(dozvoljeneRadionice, model.Radionica) < 0)
                ModelState.AddModelError("Radionica", "Izaberite ponuđenu radionicu.");

            if (Array.IndexOf(dozvoljeniNivoi, model.Nivo) < 0)
                ModelState.AddModelError("Nivo", "Izaberite ponuđeni nivo.");

            if (!ModelState.IsValid)
                return View(model);

            return View("Potvrda", model);
        }

        public ActionResult Kontakt()
        {
            ViewBag.Title = "Kontakt";
            return View();
        }
    }
}
