using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace PSARadionice.Models
{
    public class PrijavaRadionice
    {
        [Required(ErrorMessage = "Unesite ime i prezime.")]
        [StringLength(80, MinimumLength = 3, ErrorMessage = "Ime mora imati od 3 do 80 karaktera.")]
        [Display(Name = "Ime i prezime")]
        [AllowHtml]
        public string ImePrezime { get; set; }

        [Required(ErrorMessage = "Unesite email adresu.")]
        [EmailAddress(ErrorMessage = "Unesite ispravnu email adresu.")]
        [Display(Name = "Email adresa")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Izaberite radionicu.")]
        [Display(Name = "Radionica")]
        public string Radionica { get; set; }

        [Required(ErrorMessage = "Unesite nivo predznanja.")]
        [Display(Name = "Nivo predznanja")]
        public string Nivo { get; set; }

        [StringLength(300, ErrorMessage = "Poruka može imati najviše 300 karaktera.")]
        [Display(Name = "Dodatna napomena")]
        [AllowHtml]
        public string Napomena { get; set; }
    }
}
