using System.Web.Mvc;

namespace PSARadionice.Helpers
{
    public static class KarticaHelper
    {
        public static MvcHtmlString Kartica(this HtmlHelper html, string oznaka, string naslov, string opis)
        {
            TagBuilder tag = new TagBuilder("span");
            tag.AddCssClass("tag");
            tag.SetInnerText(oznaka);

            TagBuilder h2 = new TagBuilder("h2");
            h2.SetInnerText(naslov);

            TagBuilder p = new TagBuilder("p");
            p.SetInnerText(opis);

            TagBuilder article = new TagBuilder("article");
            article.AddCssClass("panel");
            article.InnerHtml = tag.ToString() + h2.ToString() + p.ToString();

            return MvcHtmlString.Create(article.ToString());
        }
    }
}
